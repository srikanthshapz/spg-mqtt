class AliasMap:
    Next_Server = 0
    Rebirth = 1
    Reboot = 2
    Dataset = 3
    Arm_Disarm_Event = 8
    Relay_Device = 10
    Fire_Event = 18
    Burglary_Event = 19
    Medical_Event = 20
    Entity_Id = 21
    Entity_Name = 22
