class Config:    
    spgproto            =        "spBv1.0"
    groupId              =       "HBT Security" 
    brokerAddr            =       "localhost"
    brokerPort           =       1886
    myUsername           =       "admin"
    myPassword           =       "changeme"
