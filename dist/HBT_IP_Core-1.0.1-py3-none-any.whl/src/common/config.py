class Config:    
    spgproto            =        "spBv1.0"
    groupId              =       "HBT Security" 
    brokerAddr            =       "localhost"
    brokerPort           =       1883
    myUsername           =       "admin"
    myPassword           =       "changeme"
